﻿using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9.Models
{
    public interface ICategory
    {
        IQueryable<Category> categories { get; }
        Category this[int id] { get; }
        Category AddCategory(Category category);
        Category UpdateCategory(Category category);

        void DeleteCategory(int id);
        void PatchCategory(int id, JsonPatchDocument<Category> patch);
    } 
}
