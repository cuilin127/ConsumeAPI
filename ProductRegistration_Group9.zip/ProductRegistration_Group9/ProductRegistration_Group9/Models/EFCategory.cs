﻿using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9.Models
{
    public class EFCategory : ICategory
    {
        private ProductRegistration_Group9Context context;
        public EFCategory(ProductRegistration_Group9Context ctx)
        {
            context = ctx;
        }
        public IQueryable<Category> categories => context.Categories;

        public Category this[int id] => categories.Where(c=>c.CategoryId==id).FirstOrDefault();

        public Category AddCategory(Category category) {
            while (categories.Where(c => c.CategoryId == category.CategoryId).Count() != 0) {
                category.CategoryId++;
            }
            context.Add<Category>(category);
            context.SaveChanges();
            return category;
        }
        public Category UpdateCategory(Category category) {
            context.Update<Category>(category);
            context.SaveChanges();
            return category;
        }
        public void DeleteCategory(int id) {
            context.Remove<Category>(categories.Where(c=>c.CategoryId==id).SingleOrDefault());
            context.SaveChanges();
        }
        public void PatchCategory(int id, JsonPatchDocument<Category> patch) {

            Category cat = categories.Where(c => c.CategoryId == id).FirstOrDefault();
            patch.ApplyTo(cat);
            context.Update<Category>(cat);
            context.SaveChanges();
        }
    }
}
