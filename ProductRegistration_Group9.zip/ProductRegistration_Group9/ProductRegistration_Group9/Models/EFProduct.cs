﻿using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9.Models
{
    public class EFProduct:IProduct
    {
        private ProductRegistration_Group9Context context;
        public EFProduct(ProductRegistration_Group9Context ctx)
        {
            context = ctx;
        }
        public IQueryable<Product> products => context.Products;


        public Product this[int id] => products.Where(p => p.ProductId == id).FirstOrDefault();

        public Product AddProduct(Product product)
        {
            while (products.Where(c => c.ProductId == product.ProductId).Count() != 0)
            {
                product.ProductId++;
            }
            context.Add<Product>(product);
            context.SaveChanges();
            return product;
        }
        public Product UpdateProduct(Product product)
        {
            context.Update<Product>(product);
            context.SaveChanges();
            return product;
        }
        public void DeleteProduct(int id)
        {
            context.Remove<Product>(products.Where(c => c.ProductId == id).SingleOrDefault());
            context.SaveChanges();
        }
        public void PatchProduct(int id, JsonPatchDocument<Product> patch)
        {

            Product prod = products.Where(c => c.ProductId == id).FirstOrDefault();
            patch.ApplyTo(prod);
            context.Update<Product>(prod);
            context.SaveChanges();
        }
    }
}

