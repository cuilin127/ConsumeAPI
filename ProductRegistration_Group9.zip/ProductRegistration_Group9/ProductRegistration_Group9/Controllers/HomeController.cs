﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProductRegistration_Group9.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9.Controllers
{
    public class HomeController : Controller
    {
        private ICategory cateRepo;
        private IProduct productRepo;
        public HomeController(ICategory cateRepository,IProduct productRepository)
        {
            cateRepo = cateRepository;
            productRepo = productRepository;
        }
        public ViewResult Index()
        {
            
            return View(productRepo.products);
        }

    }
}
