﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using ProductRegistration_Group9.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9.Controllers.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IProduct productRepo;
        public ProductController(IProduct productRepository)
        {
            productRepo = productRepository;
        }

        [HttpGet]
        public IEnumerable<Product> Get() => productRepo.products;

        [HttpGet("{id}")]
        public ActionResult<Product> Get(int id)
        {

            if (productRepo.products.Where(c => c.ProductId == id).Count() == 0)
            {
                return BadRequest("id not found");
            }
            return Ok(productRepo[id]);
        }

        [HttpPost]
        public Product Post([FromBody] Product product) =>
            productRepo.AddProduct(
                new Product
                {
                    ProductId = product.ProductId,
                    Name = product.Name,
                    Price = product.Price,
                    CategoryId = product.CategoryId
                }
                );

        [HttpPut]
        public Product Put([FromBody] Product prodPut) =>
            productRepo.UpdateProduct(prodPut);

        [HttpDelete("{id}")]
        public void Delete(int id) => productRepo.DeleteProduct(id);

        [HttpPatch("{id}")]
        public StatusCodeResult Patch(int id, [FromBody] JsonPatchDocument<Product> patch)
        {
            int res = productRepo.products.Where(c => c.ProductId == id).Count();
            if (res != 0)
            {
                productRepo.PatchProduct(id, patch);
                return Ok();
            }
            return NotFound();
        }
    }
}
