﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using ProductRegistration_Group9.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9.Controllers.APIController
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private ICategory cateRepo;
        //private IProduct productRepo;
        public CategoryController(ICategory cateRepository)
        {
            cateRepo = cateRepository;
        }
        [HttpGet]
        public IEnumerable<Category> Get() => cateRepo.categories;

        [HttpGet("{id}")]
        public ActionResult<Category> Get(int id)
        {

            if (cateRepo.categories.Where(c => c.CategoryId == id).Count() == 0) {
                return BadRequest("id not found");
            }
            return Ok(cateRepo[id]);
        }

        [HttpPost]
        public Category Post([FromBody] Category catePost)
        {
            if (ModelState.IsValid)
            {
                return cateRepo.AddCategory(
                    new Category
                    {
                        CategoryId = catePost.CategoryId,
                        Name = catePost.Name
                    }
                    );
            }
            else {
                return new Category();
            }
        }
            
        [HttpPut]
        public Category Put([FromBody] Category catePut) =>
            cateRepo.UpdateCategory(catePut);

        [HttpDelete("{id}")]
        public void Delete(int id) => cateRepo.DeleteCategory(id);

        [HttpPatch("{id}")]
        public StatusCodeResult Patch(int id, [FromBody] JsonPatchDocument<Category> patch)
        {
            int res = cateRepo.categories.Where(c=>c.CategoryId==id).Count(); 
            if (res != 0)
            {
                cateRepo.PatchCategory(id,patch);
                return Ok();
            }
            return NotFound();
        }
    }
}
