﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ProductRegistration_Group9_Consume.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text;
using System.Net.Http.Json;

namespace ProductRegistration_Group9_Consume.Controllers
{
    public class HomeController : Controller
    {

        public async Task<IActionResult> Index()
        {
            return View();
        }
        public async Task<IActionResult> CategoryPage()
        {
            List<Category> categories = new List<Category>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Category"))

                {
                    string apiRes = await response.Content.ReadAsStringAsync();
                    categories = JsonConvert.DeserializeObject<List<Category>>(apiRes);
                }
            }
            return View(categories);
        }

        public async Task<IActionResult> ProductPage()
        {
            List<Product> products = new List<Product>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Product"))

                {
                    string apiRes = await response.Content.ReadAsStringAsync();
                    products = JsonConvert.DeserializeObject<List<Product>>(apiRes);
                }
            }
            return View(products);
        }
        public IActionResult AddCategory() {
            return View();
        }
        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddCategory(Category category) {
            if (ModelState.IsValid) {
                Category receivedCategory = new Category();
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(category), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("http://localhost:8000/api/Category", content))
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedCategory = JsonConvert.DeserializeObject<Category>(apiRes);
                    }
                    return Redirect("CategoryPage");
                }
            } else {
                return View();
            }


        }

        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                Product receivedProduct = new Product();
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(product), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("http://localhost:8000/api/Product", content))
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedProduct = JsonConvert.DeserializeObject<Product>(apiRes);
                    }
                    return Redirect("ProductPage");
                }
            }
            else {
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> DeleteCategory(int id) {

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("http://localhost:8000/api/Category/" + id))
                {
                    string apiRes = await response.Content.ReadAsStringAsync();
                }
            }
            return RedirectToAction("CategoryPage");
        }

        [HttpGet]
        public async Task<IActionResult> DeleteProduct(int id)
        {

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("http://localhost:8000/api/Product/" + id))
                {
                    string apiRes = await response.Content.ReadAsStringAsync();
                }
            }
            return RedirectToAction("ProductPage");
        }

        public async Task<IActionResult> UpdateCategoryWithPut(int id) {
            Category receivedCategory = new Category();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Category/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedCategory = JsonConvert.DeserializeObject<Category>(apiRes);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                    }
                }
            }
            return View(receivedCategory);
        }
        public async Task<IActionResult> UpdateProductWithPut(int id)
        {
            Product receivedProduct = new Product();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Product/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedProduct = JsonConvert.DeserializeObject<Product>(apiRes);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                    }
                }
            }
            return View(receivedProduct);
        }
        public async Task<IActionResult> UpdateCategoryWithPatch(int id)
        {
            Category receivedCategory = new Category();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Category/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedCategory = JsonConvert.DeserializeObject<Category>(apiRes);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                    }
                }
            }
            return View(receivedCategory);
        }
        public async Task<IActionResult> UpdateProductWithPatch(int id)
        {
            Product receivedProduct = new Product();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Product/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedProduct = JsonConvert.DeserializeObject<Product>(apiRes);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                    }
                }
            }
            return View(receivedProduct);
        }
        [HttpPost]
        public async Task<IActionResult> UpdateCategoryWithPut(Category category)
        {
            if (ModelState.IsValid) {
                StringContent content = new StringContent(JsonConvert.SerializeObject(category), Encoding.UTF8, "application/json");
                using (var httpClient = new HttpClient())
                {

                    using (var resp = await httpClient.PutAsync("http://localhost:8000/api/Category/", content))
                    {
                        string apiRes = await resp.Content.ReadAsStringAsync();

                    }
                }
                return RedirectToAction("CategoryPage");
            } else {
                return View(category);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateProductWithPut(Product product)
        {
            if (ModelState.IsValid)
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(product), Encoding.UTF8, "application/json");
                using (var httpClient = new HttpClient())
                {

                    using (var resp = await httpClient.PutAsync("http://localhost:8000/api/Product/", content))
                    {
                        string apiRes = await resp.Content.ReadAsStringAsync();

                    }
                }
                return RedirectToAction("ProductPage");
            }
            else {
                return View(product);
            }
                
        }
        [HttpPost]
        public async Task<IActionResult> UpdateCategoryWithPatch(Category category)
        {
            if (ModelState.IsValid) {
                using (var httpClient = new HttpClient())
                {
                    var request = new HttpRequestMessage
                    {
                        RequestUri = new Uri("http://localhost:8000/api/Category/" + category.CategoryId),
                        Method = new HttpMethod("Patch"),
                        Content = new StringContent("[{\"op\": \"replace\", \"path\": \"Name\",\"value\":\"" + category.Name + "\"}]", Encoding.UTF8, "application/json")
                    };
                    var apiRes = await httpClient.SendAsync(request);
                }
                return RedirectToAction("CategoryPage");
            } else {
                return View(category);
            }
                
        }

        [HttpPost]
        public async Task<IActionResult> UpdateProductWithPatch(Product product)
        {
            if (ModelState.IsValid) {
                using (var httpClient = new HttpClient())
                {
                    var request = new HttpRequestMessage
                    {
                        RequestUri = new Uri("http://localhost:8000/api/Product/" + product.ProductId),
                        Method = new HttpMethod("Patch"),
                        Content = new StringContent("[{\"op\": \"replace\", \"path\": \"Name\",\"value\":\"" + product.Name + "\"},{\"op\": \"replace\", \"path\": \"Price\",\"value\":\"" + product.Price + "\"},{\"op\": \"replace\", \"path\": \"CategoryId\",\"value\":\"" + product.CategoryId + "\"}]", Encoding.UTF8, "application/json")
                    };
                    var apiRes = await httpClient.SendAsync(request);
                }
                return RedirectToAction("ProductPage");
            } else {
                return View(product);
            }
        }
        [HttpPost]
        public async Task<IActionResult> FindProduct(int id) {
            Product receivedProduct = new Product();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Product/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedProduct = JsonConvert.DeserializeObject<Product>(apiRes);
                        return View("ReadOneProduct",receivedProduct);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                        return View("ReadOneProduct", new Product());
                    }
                }
            }

            
        }
        [HttpPost]
        public async Task<IActionResult> FindCategory(int id)
        {
            Category receivedCategory = new Category();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:8000/api/Category/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiRes = await response.Content.ReadAsStringAsync();
                        receivedCategory = JsonConvert.DeserializeObject<Category>(apiRes);
                        return View("ReadOneCategory", receivedCategory);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                        return View("ReadOneCategory", new Category());
                    }
                }
            }

            
        }
    }
}
