﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9_Consume.Models
{
    public class Category
    {
        [Required(ErrorMessage = "Please Enter Your Category ID")]
        [Range(1, int.MaxValue, ErrorMessage = "Please enter a value bigger than 0") ]
        public int CategoryId { get; set; }
        [Required(ErrorMessage = "Please Enter Your Category Name")]
        public string Name { get; set; }
    }
}
