﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductRegistration_Group9_Consume.Models
{
    public class Product
    {
        [Range(1, int.MaxValue, ErrorMessage = "Please enter a value bigger than {1}")]
        public int ProductId { get; set; }
        [Required(ErrorMessage = "Please Enter Your Product Name")]
        public string Name { get; set; }
        [Range(0.01, double.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]
        public double Price { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Please enter a value bigger than {1}")]
        public int CategoryId { get; set; }
    }
}
